﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace YeniOdev.Data.Migrations
{
    public partial class kategori3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
