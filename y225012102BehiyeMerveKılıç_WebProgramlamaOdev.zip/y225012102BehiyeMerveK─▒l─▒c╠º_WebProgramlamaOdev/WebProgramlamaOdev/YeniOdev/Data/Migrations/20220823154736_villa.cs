﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace YeniOdev.Data.Migrations
{
    public partial class villa : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
