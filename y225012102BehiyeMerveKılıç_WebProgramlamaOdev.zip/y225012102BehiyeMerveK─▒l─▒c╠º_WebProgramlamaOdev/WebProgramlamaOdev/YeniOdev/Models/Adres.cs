﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YeniOdev.Models
{
    public class Adres
    {
        public int Id { get; set; }

        public string AcikAdres { get; set; }



    }
}
